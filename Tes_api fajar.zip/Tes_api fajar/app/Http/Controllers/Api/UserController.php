<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\PostResource;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{    
    /**
     * index
     *
     * @return void
     */
    public function index()
    {
        //get users
        $users = Post::latest()->paginate(5);

        //return collection of posts as a resource
        return new PostResource(true, 'List Data user', $users);
    }
    
    /**
     * store
     *
     * @param  mixed $request
     * @return void
     */
    public function store(Request $request)
    {
        //define validation rules
        $validator = Validator::make($request->all(), [
            'name'     => 'required',
            'birth_date'     => 'required',
            'birth_place'     => 'required',
            'gender'   => 'required',
        ]);

        //check if validation fails
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        //upload image
        $image = $request->file('name');
        $image->storeAs('public/users', $name->hashName());

        //create users
        $post = User::create([
            'name'     => $image->hashName(),
            'birth_date'     => $request->birth_date,
            'birth_place'     => $request->birth_place,
            'gender'   => $request->gender,
        ]);

        //return response
        return new UserResource(true, 'Data User Berhasil Ditambahkan!', $user);
    }
        
    /**
     * show
     *
     * @param  mixed $user
     * @return void
     */
    public function show(User $user)
    {
        //return single post as a resource
        return new UserResource(true, 'Data User Ditemukan!', $user);
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $post
     * @return void
     */
    public function update(Request $request, User $user)
    {
        //define validation rules
        $validator = Validator::make($request->all(), [
            'name'     => 'required',
            'birth_date'     => 'required',
            'birth_place'     => 'required',
            'gender'   => 'required',
        ]);

        //check if validation fails
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        //check if image is not empty
        if ($request->hasFile('name')) {

            //upload image
            $image = $request->file('name');
            $image->storeAs('public/users', $name->hashName());

            //delete old image
            Storage::delete('public/users/'.$users->name);

            //update post with new image
            $post->update([
            'name'     => $name->hashName(),
            'birth_date'     => $request->birth_date,
            'birth_place'     => $request->birth_place,
            'gender'   => $request->gender,
            ]);

        } else {

            //update post without image
            $post->update([
            'birth_date'     => $request->birth_date,
            'birth_place'     => $request->birth_place,
            'gender'   => $request->gender,
            ]);
        }

        //return response
        return new UserResource(true, 'Data User Berhasil Diubah!', $user);
    }
    
    /**
     * destroy
     *
     * @param  mixed $user
     * @return void
     */
    public function destroy(User $user)
    {
        //delete image
        Storage::delete('public/users/'.$users->name);

        //delete user
        $post->delete();

        //return response
        return new UserResource(true, 'Data User Berhasil Dihapus!', null);
    }
}
